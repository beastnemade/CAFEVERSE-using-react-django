import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { loadCart, saveCart } from '../utils/cartStorage';
import axios from 'axios'

const menuCategories = [
  {
    id: "drinks",
    name: "Hot Drinks",
    items: [
      {
        name: "Espresso",
        description: "Rich and bold espresso shot with a smooth, full-bodied flavor.",
        price: "350",
        image: "/public/espresso.jpg",
        popular: true,
        dietary: ["vegan"],
        calories: 5
      },
      {
        name: "Cappuccino",
        description: "Espresso with steamed milk and a thick layer of milk foam.",
        price: "475",
        image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=300&q=80",
        popular: true,
        dietary: ["vegetarian"],
        calories: 120
      },
      {
        name: "Latte",
        description: "Smooth espresso with steamed milk and a light layer of foam.",
        price: "495",
        image: "/public/latte.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 135
      },
      {
        name: "Americano",
        description: "Espresso with hot water for a bold, rich flavor.",
        price: "375",
        image: "/public/americano.jpg",
        dietary: ["vegan"],
        calories: 10
      },
      {
        name: "Mocha",
        description: "Espresso with rich chocolate and steamed milk.",
        price: "525",
        image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=300&q=80",
        dietary: ["vegetarian"],
        calories: 250
      },
      {
        name: "Macchiato",
        description: "Espresso with a small amount of steamed milk.",
        price: "425",
        image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=300&q=80",
        dietary: ["vegetarian"],
        calories: 80
      },
      {
        name: "Flat White",
        description: "Espresso with velvety microfoam for a smooth texture.",
        price: "485",
        image: "/public/flat_white.jpg",
        dietary: ["vegetarian"],
        calories: 110
      },
      {
        name: "Hot Chocolate",
        description: "Rich chocolate with steamed milk and whipped cream.",
        price: "450",
        image: "/public/hot_chocalate.jpg",
        dietary: ["vegetarian"],
        calories: 280
      }
    ]
  },
  {
    id: "cold-drinks",
    name: "Cold Drinks",
    items: [
      {
        name: "Iced Latte",
        description: "Chilled espresso with cold milk over ice.",
        price: "515",
        image: "/public/iced_latte.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 140
      },
      {
        name: "Iced Cappuccino",
        description: "Espresso with cold milk and foam over ice.",
        price: "525",
        image: "/public/iced_cappuccino.jpg",
        dietary: ["vegetarian"],
        calories: 125
      },
      {
        name: "Cold Brew",
        description: "Smooth, low-acid coffee brewed for 18 hours.",
        price: "495",
        image: "/public/cold_brew.jpg",
        popular: true,
        dietary: ["vegan"],
        calories: 5
      },
      {
        name: "Iced Mocha",
        description: "Espresso with chocolate and cold milk over ice.",
        price: "575",
        image: "/public/iced_mocha.jpg",
        dietary: ["vegetarian"],
        calories: 260
      },
      {
        name: "Frappuccino",
        description: "Blended coffee drink with ice and milk.",
        price: "625",
        image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=300&q=80",
        seasonal: true,
        dietary: ["vegetarian"],
        calories: 320
      }
    ]
  },
  {
    id: "breakfast",
    name: "Breakfast",
    items: [
      {
        name: "Avocado Toast",
        description: "Sourdough toast with fresh avocado, sea salt, and red pepper flakes.",
        price: "850",
        image: "/public/avocado_toast.jpg",
        popular: true,
        dietary: ["vegetarian", "vegan"],
        calories: 280
      },
      {
        name: "Eggs Benedict",
        description: "Poached eggs on English muffin with hollandaise sauce.",
        price: "1295",
        image: "/public/eggs_benedict.jpg",
        dietary: ["vegetarian"],
        calories: 450
      },
      {
        name: "Breakfast Burrito",
        description: "Scrambled eggs, cheese, and vegetables in a tortilla.",
        price: "975",
        image: "/public/burrito.jpg",
        dietary: ["vegetarian"],
        calories: 380
      },
      {
        name: "Oatmeal Bowl",
        description: "Steel-cut oats with berries, nuts, and honey.",
        price: "725",
        image: "/public/oatmeal_bowl.jpg",
        dietary: ["vegetarian", "vegan"],
        calories: 220
      },
      {
        name: "Greek Yogurt Parfait",
        description: "Greek yogurt with granola and fresh berries.",
        price: "695",
        image: "/public/greek_yogurt_parfait.jpg",
        dietary: ["vegetarian"],
        calories: 180
      }
    ]
  },
  {
    id: "food",
    name: "Food & Pastries",
    items: [
      {
        name: "Blueberry Muffin",
        description: "Freshly baked muffin loaded with sweet blueberries.",
        price: "325",
        image: "/public/blueberry_muffin.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 320
      },
      {
        name: "Croissant",
        description: "Buttery, flaky French pastry baked fresh daily.",
        price: "350",
        image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=300&q=80",
        popular: true,
        dietary: ["vegetarian"],
        calories: 280
      },
      {
        name: "Banana Bread",
        description: "Moist and flavorful bread with ripe bananas.",
        price: "300",
        image: "/public/banana_bread.jpg",
        dietary: ["vegetarian", "vegan"],
        calories: 240
      },
      {
        name: "Chocolate Chip Cookie",
        description: "Warm, gooey cookie with chocolate chips.",
        price: "275",
        image: "/public/choc_chip_cookie.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 180
      },
      {
        name: "Cinnamon Roll",
        description: "Sweet roll with cinnamon and cream cheese frosting.",
        price: "425",
        image: "/public/cinnamon.jpg",
        dietary: ["vegetarian"],
        calories: 420
      },
      {
        name: "Scone",
        description: "Traditional British scone with clotted cream and jam.",
        price: "375",
        image: "/public/scone.jpg",
        dietary: ["vegetarian"],
        calories: 260
      },
      {
        name: "Quiche Lorraine",
        description: "Savory pie with eggs, cheese, and bacon.",
        price: "895",
        image: "/public/quiche_lorraine.jpg",
        dietary: ["vegetarian"],
        calories: 380
      },
      {
        name: "Grilled Cheese",
        description: "Classic sandwich with melted cheese and butter.",
        price: "750",
        image: "/public/grilled_cheese.jpg",
        dietary: ["vegetarian"],
        calories: 320
      }
    ]
  },
  {
    id: "tea",
    name: "Tea & Refreshers",
    items: [
      {
        name: "Chai Latte",
        description: "Spiced black tea with steamed milk and honey.",
        price: "450",
        image: "/public/chai_latte.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 140
      },
      {
        name: "Green Tea",
        description: "Freshly brewed green tea with natural antioxidants.",
        price: "325",
        image: "/public/green_tea.jpg",
        dietary: ["vegan"],
        calories: 0
      },
      {
        name: "Herbal Tea",
        description: "Caffeine-free herbal blend with calming properties.",
        price: "325",
        image: "/public/herbal_tea.jpg",
        dietary: ["vegan"],
        calories: 0
      },
      {
        name: "Iced Tea",
        description: "Refreshing iced tea with lemon and mint.",
        price: "375",
        image: "/public/ice_tea.jpg",
        dietary: ["vegan"],
        calories: 5
      },
      {
        name: "Earl Grey",
        description: "Classic black tea with bergamot oil.",
        price: "350",
        image: "/public/earl_grey.jpg",
        dietary: ["vegan"],
        calories: 0
      },
      {
        name: "Matcha Latte",
        description: "Japanese green tea powder with steamed milk.",
        price: "550",
        image: "/public/matcha_latte.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 120
      }
    ]
  },
  {
    id: "desserts",
    name: "Desserts",
    items: [
      {
        name: "Tiramisu",
        description: "Italian dessert with coffee-soaked ladyfingers and mascarpone.",
        price: "695",
        image: "/public/tiramisu.jpg",
        popular: true,
        dietary: ["vegetarian"],
        calories: 280
      },
      {
        name: "Chocolate Cake",
        description: "Rich chocolate layer cake with ganache frosting.",
        price: "575",
        image: "/public/choc_cake.jpg",
        dietary: ["vegetarian"],
        calories: 320
      },
      {
        name: "Cheesecake",
        description: "Creamy New York style cheesecake with berry compote.",
        price: "625",
        image: "/public/cheese_cake.jpg",
        dietary: ["vegetarian"],
        calories: 380
      },
      {
        name: "Apple Pie",
        description: "Classic pie with cinnamon-spiced apples and flaky crust.",
        price: "550",
        image: "/public/apple_pie.jpg",
        seasonal: true,
        dietary: ["vegetarian"],
        calories: 260
      }
    ]
  }
];

const Menu = () => {
  const navigate = useNavigate();
  const [cart, setCart] = useState(() => loadCart());
  const [nameQuery, setNameQuery] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const formatPriceToRs = (priceString) => {
    const numeric = parseFloat(String(priceString).replace(/[^0-9.]/g, ""));
    if (Number.isNaN(numeric)) return priceString;
    return `${numeric.toFixed(2)} Rs`;
  };

  const getNumericPrice = (priceString) => {
    const numeric = parseFloat(String(priceString).replace(/[^0-9.]/g, ""));
    return Number.isNaN(numeric) ? null : numeric;
  };

  useEffect(() => {
    const fetchdata = async () =>{
      try{
        const data = await axios.get('http://127.0.0.1:8000/api/menu/')
        console.log(data.data.data)
      }catch(error){
        console.log(error)
      }
    }
    fetchdata()
  },[])

  // Save cart to localStorage whenever cart changes
  useEffect(() => {
    saveCart(cart);
  }, [cart]);

  // Add to cart
  const addToCart = (item) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.name === item.name);
      let newCart;
      if (existingItem) {
        newCart = prevCart.map(cartItem =>
          cartItem.name === item.name
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        newCart = [...prevCart, { ...item, quantity: 1 }];
      }
      return newCart;
    });
  };

  const updateQuantity = (itemName, newQuantity) => {
    setCart(prevCart => {
      let newCart;
      if (newQuantity <= 0) {
        newCart = prevCart.filter(item => item.name !== itemName);
      } else {
        newCart = prevCart.map(item =>
          item.name === itemName
            ? { ...item, quantity: newQuantity }
            : item
        );
      }
      return newCart;
    });
  };


  const getItemQuantity = (itemName) => {
    const cartItem = cart.find(item => item.name === itemName);
    return cartItem ? cartItem.quantity : 0;
  };

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-100 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 mt-12">
          <h1 className="text-4xl md:text-5xl font-bold text-orange-900 mb-2">Our Menu</h1>
          <p className="text-gray-600">Freshly brewed coffee, cozy bites, and sweet finishes</p>
        </div>

        {/* Search & Price Filters */}
        <div className="bg-white rounded-xl p-6 mb-10 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-orange-900 mb-2">Search by name</label>
              <input
                type="text"
                placeholder="e.g., Latte, Muffin"
                value={nameQuery}
                onChange={(e) => setNameQuery(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-200"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-orange-900 mb-2">Max price</label>
              <input
                type="number"
                min="0"
                step="400"
                placeholder="e.g., 400"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-200"
              />
            </div>
            <div className="flex md:items-end">
              <button
                onClick={() => { setNameQuery(""); setMaxPrice(""); }}
                className="w-full md:w-auto px-6 py-2 rounded-lg bg-orange-900 text-white font-semibold hover:bg-orange-700 transition"
              >
                Clear
              </button>
            </div>
          </div>
        </div>
        {/* Sections */}
        {menuCategories.map((category) => {
          const filteredCategoryItems = category.items.filter((item) => {
            const matchesName = nameQuery
              ? item.name.toLowerCase().includes(nameQuery.toLowerCase())
              : true;
            const matchesPrice = maxPrice
              ? (getNumericPrice(item.price) ?? Infinity) <= parseFloat(maxPrice)
              : true;
            return matchesName && matchesPrice;
          });
          if (filteredCategoryItems.length === 0) return null;
          return (
          <div key={category.id} className="mb-14">
            <div className="flex items-center mb-6">
              <h2 className="text-2xl font-bold text-orange-900">{category.name}</h2>
              <div className="ml-4 flex-1 h-px bg-orange-200"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCategoryItems.map((item) => {
                const itemQuantity = getItemQuantity(item.name);
                const subtitle = item.description.length > 60
                  ? `${item.description.substring(0, 57)}...`
                  : item.description;
                return (
                  <div key={item.name} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                      {item.popular && (
                        <div className="absolute top-2 left-2 bg-orange-900 text-white px-2 py-1 rounded-full text-xs font-semibold">
                          Popular
                        </div>
                      )}
                      {item.seasonal && (
                        <div className="absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
                          Seasonal
                        </div>
                      )}
                    </div>

                    <div className="p-5">
                      <h3 className="text-lg font-bold text-gray-800 mb-1">{item.name}</h3>
                      <p className="text-gray-500 text-sm mb-4">{subtitle}</p>

                      <div className="flex items-center justify-between">
                        <span className="text-base font-semibold text-orange-700">
                          {formatPriceToRs(item.price)}
                        </span>

                        {itemQuantity > 0 ? (
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.name, itemQuantity - 1)}
                              className="w-8 h-8 rounded-full bg-orange-100 text-orange-700 hover:bg-orange-200 transition-colors duration-200 flex items-center justify-center font-semibold"
                            >
                              -
                            </button>
                            <span className="w-8 text-center font-bold text-orange-700">
                              {itemQuantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.name, itemQuantity + 1)}
                              className="w-8 h-8 rounded-full bg-orange-100 text-orange-700 hover:bg-orange-200 transition-colors duration-200 flex items-center justify-center font-semibold"
                            >
                              +
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToCart(item)}
                            className="px-4 py-2 rounded-full bg-orange-900 text-white text-sm font-semibold hover:bg-orange-800 transition-colors duration-200 shadow-sm"
                          >
                            Add to Cart
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          );
        })}

        {/* View Cart Button */}
        {cartItemCount > 0 && (
          <div className="fixed bottom-6 right-6 z-50">
            <button
              onClick={() => navigate('/cart')}
              className="flex items-center gap-2 bg-orange-900 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:bg-orange-800 transition-colors duration-300 text-lg"
              aria-label="View Cart"
            >
              <svg className="w-6 h-6 mr-1" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-2.5 5m2.5-5l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m8 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01" />
              </svg>
              View Cart
              <span className="ml-2 bg-white text-orange-900 px-2 py-1 rounded-full text-sm font-bold">
                {cartItemCount}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Menu; 